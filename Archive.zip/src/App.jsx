import ComingSoon from "./ComingSoon";

export default function App() {
  return <ComingSoon />;
}
